/*
  pozLib.h - PoZ's fucntions library
  
*/

// ensure this library description is only included once
#ifndef pozLib_h
#define pozLib_h
#include "Arduino.h"
#include <WiFi.h>

class pozWifi {

    public:
        pozWifi(String ssid, String pass, int led);
        void connect();
        void reConnect();
        String _ssid;
        String _pass;
        int _led;

};


#endif
