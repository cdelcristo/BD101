#include "pozLib.h"

pozWifi::pozWifi(String ssid, String pass, int led)
{
    pinMode(led, OUTPUT);
    _ssid = ssid;
    _pass = pass;
    _led = led;
}

void pozWifi::connect()
{
    Serial.println("Connecting to Wireless Network...");
    WiFi.begin(_ssid.c_str(), _pass.c_str());
    while (WiFi.status() != WL_CONNECTED)
    {
        delay(500);
        Serial.print(".");
    }
    Serial.println("");
    Serial.print("WiFi connected! IP: ");
    digitalWrite(_led, HIGH);
    Serial.println(WiFi.localIP());
}

void pozWifi::reConnect()
{
    Serial.print("Reconnecting to WiFi...");
    WiFi.disconnect();
    WiFi.begin(_ssid.c_str(), _pass.c_str());
}

