#define WIFI_PASSWORD "AjiDulce12"
#define WIFI_SSID "Garden"
#define MOSQUITTO_SERVER "192.168.16.189"
#define MOSQUITTO_SERVER_PORT 1883
#define INFLUX_DB "indoorGarden"
// #define INFLUX_DB "homeGarden"
#define INFLUX_SERVER "192.168.16.189"
#define INFLUX_MEASURE_1 "indoor"