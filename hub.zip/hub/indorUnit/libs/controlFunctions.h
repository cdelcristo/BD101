/*
  controlFunctions.h - Library for grow tent control.
  Created by Carlos J. Delcristo, April 9, 2020.
  Released into the public domain.
*/

#ifndef functions
#define functions

#include "Arduino.h"

class Config
{

  public:
    Config();
    void connectWifi();

};


#endif